public class HelloWorld
{
    public static void main()
    {
        System.out.print("Hello, World!"); 
    }
}
