import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
public class Launcher5
{
    public static void main (String[] args)
    {
        CheesePlease5 myProgram = new CheesePlease5();
        LwjglApplication launcher = new LwjglApplication( myProgram );
    }
}