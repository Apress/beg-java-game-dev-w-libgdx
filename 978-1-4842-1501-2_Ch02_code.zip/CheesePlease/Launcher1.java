import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
public class Launcher1
{
    public static void main (String[] args)
    {
        CheesePlease1 myProgram = new CheesePlease1();
        LwjglApplication launcher = new LwjglApplication( myProgram );
    }
}