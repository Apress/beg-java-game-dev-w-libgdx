import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
public class Launcher4
{
    public static void main (String[] args)
    {
        CheesePlease4 myProgram = new CheesePlease4();
        LwjglApplication launcher = new LwjglApplication( myProgram );
    }
}