import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
public class Launcher2
{
    public static void main (String[] args)
    {
        CheesePlease2 myProgram = new CheesePlease2();
        LwjglApplication launcher = new LwjglApplication( myProgram );
    }
}