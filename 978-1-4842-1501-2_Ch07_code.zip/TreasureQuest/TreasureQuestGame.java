public class TreasureQuestGame extends BaseGame
{
    public void create() 
    {  
        GameScreen gs = new GameScreen(this);
        setScreen( gs );
    }
}
