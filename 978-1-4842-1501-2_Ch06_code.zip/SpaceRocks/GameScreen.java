import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.math.MathUtils;
import java.util.ArrayList;

public class GameScreen extends BaseScreen
{
    private BaseActor background;
    private PhysicsActor spaceship;
    private BaseActor rocketfire;
    
    // create "base" objects to clone later
    private PhysicsActor baseLaser;
    private AnimatedActor baseExplosion;
    
    private ArrayList<PhysicsActor> laserList;
    private ArrayList<PhysicsActor> rockList;
    private ArrayList<BaseActor> removeList;
    
    // game world dimensions
    final int mapWidth = 800;
    final int mapHeight = 600;

    public GameScreen(BaseGame g)
    {
        super(g);
    }

    public void create() 
    {        
        background = new BaseActor();
        background.setTexture( new Texture(Gdx.files.internal("assets/space.png")) );
        background.setPosition( 0, 0 );
        mainStage.addActor( background );

        spaceship = new PhysicsActor();
        Texture shipTex = new Texture(Gdx.files.internal("assets/spaceship.png"));
        shipTex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
        spaceship.storeAnimation( "default", shipTex );
        spaceship.setPosition( 400,300 );
        spaceship.setOriginCenter();
        spaceship.setMaxSpeed(200);
        spaceship.setDeceleration(20);
        spaceship.setEllipseBoundary();
        mainStage.addActor(spaceship);

        rocketfire = new BaseActor();
        rocketfire.setPosition(-28,24);
        Texture fireTex = new Texture(Gdx.files.internal("assets/fire.png"));
        fireTex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
        rocketfire.setTexture( fireTex );
        spaceship.addActor(rocketfire);
        
        // lasers
        
        baseLaser = new PhysicsActor();
        Texture laserTex = new Texture(Gdx.files.internal("assets/laser.png"));
        laserTex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
        baseLaser.storeAnimation( "default", laserTex );
        
        baseLaser.setMaxSpeed(400);
        baseLaser.setDeceleration(0);
        baseLaser.setEllipseBoundary();
        baseLaser.setOriginCenter();
        baseLaser.setAutoAngle(true);
        
        laserList = new ArrayList<PhysicsActor>();
        
        // rocks
        
        rockList = new ArrayList<PhysicsActor>();
        
        int numRocks = 6;
        for (int n = 0; n < numRocks; n++)
        {
            PhysicsActor rock = new PhysicsActor();
            
            String fileName = "assets/rock" + (n%4) + ".png";
            Texture rockTex = new Texture(Gdx.files.internal(fileName));
            rockTex.setFilter(TextureFilter.Linear, TextureFilter.Linear);
            rock.storeAnimation( "default", rockTex );
            
            rock.setPosition(800 * MathUtils.random(), 600 * MathUtils.random() );
            rock.setOriginCenter();
            rock.setEllipseBoundary();
            rock.setAutoAngle(false);
            
            float speedUp = MathUtils.random(0.0f, 1.0f);
            rock.setVelocityAS( 360 * MathUtils.random(), 75 + 50*speedUp );
            rock.addAction( Actions.forever( Actions.rotateBy(360, 2 - speedUp) ) );
            
            mainStage.addActor(rock);
            rockList.add(rock);
            rock.setParentList(rockList);
        }
        
        // explosions
        
        baseExplosion = new AnimatedActor();
        Animation explosionAnim = GameUtils.parseSpriteSheet(
            "assets/explosion.png", 6, 6, 0.03f, PlayMode.NORMAL);
        baseExplosion.storeAnimation( "default", explosionAnim );
        baseExplosion.setWidth(96);
        baseExplosion.setHeight(96);
        baseExplosion.setOriginCenter();
        
        removeList = new ArrayList<BaseActor>();
    }

    public void update(float dt) 
    {   
        // process input
        spaceship.setAccelerationXY(0,0);

        if (Gdx.input.isKeyPressed(Keys.LEFT)) 
            spaceship.rotateBy(180 * dt);
        if (Gdx.input.isKeyPressed(Keys.RIGHT))
            spaceship.rotateBy(-180 * dt);
        if (Gdx.input.isKeyPressed(Keys.UP)) 
            spaceship.addAccelerationAS(spaceship.getRotation(), 100);
            
        rocketfire.setVisible( Gdx.input.isKeyPressed(Keys.UP) );
        
        // wrap to screen
        wraparound( spaceship );
        
        for ( PhysicsActor rock : rockList )
        {
            wraparound( rock );
        }
        
        removeList.clear();
        for ( PhysicsActor laser : laserList )
        {
            wraparound( laser );
            if ( !laser.isVisible() )
                removeList.add( laser );
                
            for ( PhysicsActor rock : rockList )
            {
                if ( laser.overlaps(rock, false) )
                {
                    removeList.add( laser );
                    removeList.add( rock );
                    
                    AnimatedActor explosion = baseExplosion.clone();
                    explosion.moveToOrigin(rock);
                    mainStage.addActor(explosion);
                    explosion.addAction( Actions.sequence(Actions.delay(1.08f), Actions.removeActor()) );     
                }
            }
        }

        for (BaseActor ba : removeList)
        {
            ba.destroy();
        }
    }

    // InputProcessor methods for handling discrete input
    public boolean keyDown(int keycode)
    {
        if (keycode == Keys.P)    
            togglePaused();

        if (keycode == Keys.R)    
            game.setScreen( new GameScreen(game) );
            
        if (keycode == Keys.SPACE)
        {
            PhysicsActor laser = baseLaser.clone();
            laser.moveToOrigin( spaceship );
            laser.setVelocityAS( spaceship.getRotation(), 400 );
            laserList.add(laser);
            laser.setParentList(laserList);
            mainStage.addActor(laser);

            laser.addAction( 
                Actions.sequence(Actions.delay(2), Actions.fadeOut(0.5f), Actions.visible(false)) );     
        }
        
        return false;
    }

    public void wraparound(BaseActor ba)
    {
        if ( ba.getX() + ba.getWidth() < 0 )
            ba.setX( mapWidth );
        if ( ba.getX() > mapWidth )
            ba.setX( -ba.getWidth() );
        if ( ba.getY() + ba.getHeight() < 0 )
            ba.setY( mapHeight );
        if ( ba.getY() > mapHeight )
            ba.setY( -ba.getHeight() );
    }
}